<?php
$config = ['merchantId'=>xxxx, // 用户id
           'privateKey'=>'xxxxxxxxxxxxxxxxx',  // 用户秘钥
           'url'=>'http://xxx.com/', //下单地址
            ];
$data['status'] = $_POST['status'];
$data['time'] = $_POST['time'];
$data['outTradeNo'] = $_POST['outTradeNo'];  // 商户单号
$data['amount'] = $_POST['price'];   // 充值金额
$data['sig'] = $_POST['sig'];       // 验证码
$data['tradeNo'] = $_POST['tradeNo'];     // 官方单号
$data['realprice'] = $_POST['realprice'];//真实支付金额，商家需要根据真实支付金额给用户回调上分
if ($data['sig'] == md5($config['privateKey'].$data['amount'].$data['time'].$config['merchantId'].$data['outTradeNo'].'0'.$data['realprice'])) {
    // 验证成功，注意根据单号辨别重复回调
	echo 1;
} else {
	echo 0;
}
