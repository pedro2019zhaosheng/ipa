<?php
$config = ['merchantId'=>xxxxx, // 商户号
           'privateKey'=>'xxxxxxxxxxx',  // 用户秘钥
           'url'=>'http://xxxxx.com/bankpay', //下单地址
            ];

$data['merchantId'] = $config['merchantId'];
$data['notifyUrl'] = 'http://127.0.0.1/callback.php';  //回调地址
$data['userid'] = 123;//用户id
$data['outTradeNo'] = time();  // 用户订单号
$data['price'] = 15;       // 金额，单位元
$data['subject'] = 'test';    // 标题
$data['info'] = 'test';   // 详细信息
$data['time'] = time();
$data['sig'] = md5($config['privateKey'].$data['price'].$data['time'].$config['merchantId'].$data['outTradeNo']);

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $config['url']);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'X-AjaxPro-Method:ShowList',
    'User-Agent:Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/33.0.1750.154 Safari/537.36'
));
$arr['data'] = base64_encode(json_encode($data));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $arr);
curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); //不验证证书
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false); //不验证证书
$output = curl_exec($ch);

$error = curl_error($ch);
if ($error) {
	var_dump(error);
var_dump($output);
}

curl_close($ch);
echo $output;
